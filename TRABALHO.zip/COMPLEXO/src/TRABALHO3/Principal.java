/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package TRABALHO3;

/**
 *
 * @author xavie
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Complexo iva = new Complexo();
        iva.setNumeroReal1(7);
        iva.setNumeroReal2(4);
        iva.setNumeroImaginario1(8);
        iva.setNumeroImaginario2(1);
        iva.somaComplexo();
        
        
        System.out.println("SOMA COMPLEXO");
        System.out.println("");
        System.out.println("Numero Item:  " + iva.getNumeroReal1());
        System.out.println("Descricao:" + iva.getNumeroReal2());
        System.out.println("Quantidade Comprada: " + iva.getNumeroImaginario1());
        System.out.println("Valor Unitario R$: " + iva.getNumeroImaginario2());
        System.out.println("Valor Total R$: " + iva.somaComplexo());
        System.out.println("");
        
    }
    
}
