/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TRABALHO4;

/**
 *
 * @author xavie
 */
public class Datas {
    
    private int dia;
    private int mes;
    private int ano;
    
    
    public void setDia(int dia) {
        if (dia >= 1 && dia <= 31) {
            this.dia = dia;
        } else {
            this.dia = 0;
        }
    }

    public void setMes(int mes) {
        if (mes >= 1 && mes <= 12) {
            this.mes = mes;
        } else {
            this.mes = 0;
        }
    }

    public void setAno(int ano) {
        if (ano >= 1880 && ano <= 2023) {
            this.ano = ano;
        } else {
            this.ano = 0;
        }
    }

    public String mostrarData() {
        return String.format("%02d/%02d/%04d", dia, mes, ano);
    
    }
   

public void proximoDia() {
        if(this.dia < 31) {
            this.dia++;
        } else if (this.mes == 2 && this.dia == 28) {
            this.dia = 1;
            this.mes++;
        } else if ((this.mes == 4 || this.mes == 6 || this.mes == 9 || this.mes == 11) && this.dia == 30) {
            this.dia = 1;
            this.mes++;
        } else if (this.dia == 31 && this.mes == 12) {
            this.dia = 1;
            this.mes = 1;
            this.ano++;
        } else {
            this.dia = 1;
            this.mes++;
        
    }
}
}