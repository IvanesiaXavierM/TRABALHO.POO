/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package TRABALHO4;

/**
 *
 * @author xavie
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Datas data1 = new Datas();
        data1.setDia(18);
        data1.setMes(07);
        data1.setAno(2001);

        Datas data2 = new Datas();
        data2.setDia(29);
        data2.setMes(8);
        data2.setAno(1993);

        Datas data3 = new Datas();
        data3.setDia(04);
        data3.setMes(01);
        data3.setAno(2012);

        
        
        System.out.println("MOSTRA DATAS");
        System.out.println("");
        System.out.println("Data1: " + data1.mostrarData());
        data1.proximoDia();
        System.out.println("Proximo Data1: " + data1.mostrarData());
        System.out.println("");

        System.out.println("Data2: " + data2.mostrarData());
        data2.proximoDia();
        System.out.println("Proximo Data2: " + data2.mostrarData());
        System.out.println("");

        System.out.println("Data3: " + data3.mostrarData());
        data3.proximoDia();
        System.out.println("Proximo Data3: " + data3.mostrarData());
        System.out.println("");
    }
}
    
    

