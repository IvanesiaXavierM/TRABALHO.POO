/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


package TRABALHO3;


/**
 *
 * @author xavier
 */
public class Empregados {
    
   
    
    private String primeiroNome;
    private String sobrenome;
    private double salarioMensal;
    private static final double SALARIO_MINIMO_VIGENTE = 1100.00;
    

    public void setPrimeiroNome(String primeiroNome) {
        this.primeiroNome = primeiroNome;
   }

    public void setSobrenome(String sobrenome) {
        this.sobrenome = sobrenome;
   }

    public void setSalarioMensal(double salarioMensal) {
        if (salarioMensal < SALARIO_MINIMO_VIGENTE) {
            this.salarioMensal = SALARIO_MINIMO_VIGENTE;
        } else {
            this.salarioMensal = salarioMensal;
        }
    }
   
     public double salarioAnual() {
        return salarioMensal * 12;

    }

    public void aumentarSalario() {
        salarioMensal *= 1.1;
    }

    public String mostrarInformacoes() {
        return "PrimeiroNome: " + primeiroNome +"\nSobreNome: " + sobrenome +"\nSalarioMensal: R$" + String.format("%.2f", salarioMensal);
    }
}

   

    
   
    
    
    

