/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package trabalho1;

/**
 *
 * @author xavie
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Fatura iva = new Fatura();
        iva.setNumeroItem(78000);
        iva.setDescricao("Calca");
        iva.setQuantidadeComprada(4);
        iva.setValorUnitario (115.00);
        iva.valorTotal();
        
        
        System.out.println("FATURA");
        System.out.println("");
        System.out.println("Numero Item:  " + iva.getNumeroItem());
        System.out.println("Descricao:" + iva.getDescricao());
        System.out.println("Quantidade Comprada: " + iva.getQuantidadeComprada());
        System.out.println("Valor Unitario R$: " + iva.getValorUnitario());
        System.out.println("Valor Total R$: " + iva.valorTotal());
        System.out.println("");
        
        
        
    }
    
    
    
}
